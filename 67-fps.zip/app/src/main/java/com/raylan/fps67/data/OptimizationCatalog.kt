package com.raylan.fps67.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LayersClear
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SyncDisabled
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.filled.WifiOff

object OptimizationCatalog {

    val restoreCommands: List<String> = listOf(
        "cmd appops set --all RUN_IN_BACKGROUND allow",
        "cmd power set-fixed-performance-mode-enabled false",
        "cmd thermalservice reset",
        "setprop debug.hwui.renderer \"\"",
        "settings put global auto_sync 1",
        "setprop debug.egl.hw 0",
        "setprop debug.hwui.fps_divisor 0",
        "settings put global window_animation_scale 1.0",
        "settings put global transition_animation_scale 1.0",
        "settings put global animator_duration_scale 1.0",
        "settings delete system peak_refresh_rate",
        "settings delete system min_refresh_rate",
        "settings put system pointer_speed 0",
        "setprop debug.sf.disable_backpressure 0",
        "setprop debug.egl.swapinterval 1",
        "dumpsys deviceidle unforce",
        "settings delete global tcp_default_init_rwnd",
        "settings put global wifi_scan_always_enabled 1"
    )

    val fullRestoreScript: String = restoreCommands.joinToString("; ")

    val tweaks: List<OptimizationTweak> = listOf(
        // Desempenho (10 funções)
        OptimizationTweak(
            id = 1,
            title = "Compilação ART Rápida",
            subtitle = "Compila pacotes com speed-profile para abrir jogos rápido",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "cmd package compile -m speed-profile -a",
            revertCommand = null,
            icon = Icons.Filled.RocketLaunch
        ),
        OptimizationTweak(
            id = 2,
            title = "Limpar Cache Global",
            subtitle = "Libera armazenamento temporário acumulado do sistema",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "pm trim-caches 999G",
            revertCommand = null,
            icon = Icons.Filled.CleaningServices
        ),
        OptimizationTweak(
            id = 3,
            title = "Proibir Execução em 2º Plano",
            subtitle = "Restringe processos em segundo plano consumindo CPU",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "cmd appops set --all RUN_IN_BACKGROUND ignore",
            revertCommand = "cmd appops set --all RUN_IN_BACKGROUND allow",
            icon = Icons.Filled.DoNotDisturbOn
        ),
        OptimizationTweak(
            id = 4,
            title = "Modo Performance Fixo",
            subtitle = "Trava clocks em perfil de alto desempenho sustentado",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "cmd power set-fixed-performance-mode-enabled true",
            revertCommand = "cmd power set-fixed-performance-mode-enabled false",
            icon = Icons.Filled.Bolt
        ),
        OptimizationTweak(
            id = 5,
            title = "Desativar Limite Térmico SW",
            subtitle = "Remove redução artificial de FPS por software térmico",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "cmd thermalservice override-status 0",
            revertCommand = "cmd thermalservice reset",
            icon = Icons.Filled.Thermostat
        ),
        OptimizationTweak(
            id = 6,
            title = "Renderização GPU SkiaGL",
            subtitle = "Define pipeline gráfico OpenGL Skia para maior fluidez",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "setprop debug.hwui.renderer skiagl",
            revertCommand = "setprop debug.hwui.renderer \"\"",
            icon = Icons.Filled.DeveloperBoard
        ),
        OptimizationTweak(
            id = 7,
            title = "Compactar Memória RAM",
            subtitle = "Envia sinal de limpeza de RAM crítica para liberar memória",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "am send-trim-memory --all RUNNING_CRITICAL",
            revertCommand = null,
            icon = Icons.Filled.Memory
        ),
        OptimizationTweak(
            id = 8,
            title = "Pausar Sincronização Auto",
            subtitle = "Evita picos de CPU/rede durante partidas competitivas",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "settings put global auto_sync 0",
            revertCommand = "settings put global auto_sync 1",
            icon = Icons.Filled.SyncDisabled
        ),
        OptimizationTweak(
            id = 9,
            title = "Prioridade Máxima de GPU",
            subtitle = "Força composição via aceleração de hardware EGL",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "setprop debug.egl.hw 1",
            revertCommand = "setprop debug.egl.hw 0",
            icon = Icons.Filled.VideogameAsset
        ),
        OptimizationTweak(
            id = 10,
            title = "Remover Divisor de FPS",
            subtitle = "Impede limitação de quadros no renderizador HWUI",
            category = OptimizationCategory.PERFORMANCE,
            applyCommand = "setprop debug.hwui.fps_divisor 1",
            revertCommand = "setprop debug.hwui.fps_divisor 0",
            icon = Icons.Filled.Speed
        ),

        // Tela & Toque (8 funções)
        OptimizationTweak(
            id = 11,
            title = "Animação de Janela 0.0x",
            subtitle = "Elimina atrasos visuais na abertura de janelas",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put global window_animation_scale 0.0",
            revertCommand = "settings put global window_animation_scale 1.0",
            icon = Icons.Filled.Animation
        ),
        OptimizationTweak(
            id = 12,
            title = "Animação de Transição 0.0x",
            subtitle = "Deixa trocas de tela instantâneas sem latência",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put global transition_animation_scale 0.0",
            revertCommand = "settings put global transition_animation_scale 1.0",
            icon = Icons.Filled.FastForward
        ),
        OptimizationTweak(
            id = 13,
            title = "Duração Animator 0.0x",
            subtitle = "Remove duração de animações do sistema Android",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put global animator_duration_scale 0.0",
            revertCommand = "settings put global animator_duration_scale 1.0",
            icon = Icons.Filled.Tune
        ),
        OptimizationTweak(
            id = 14,
            title = "Taxa Máxima de Hz",
            subtitle = "Libera pico de atualização da tela para 120.0 Hz",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put system peak_refresh_rate 120.0",
            revertCommand = "settings delete system peak_refresh_rate",
            icon = Icons.Filled.DisplaySettings
        ),
        OptimizationTweak(
            id = 15,
            title = "Taxa Mínima Estável",
            subtitle = "Mantém o painel travado em 120.0 Hz sem quedas",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put system min_refresh_rate 120.0",
            revertCommand = "settings delete system min_refresh_rate",
            icon = Icons.Filled.GraphicEq
        ),
        OptimizationTweak(
            id = 16,
            title = "Resposta de Toque Ultra",
            subtitle = "Aumenta sensibilidade do ponteiro para nível máximo (7)",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "settings put system pointer_speed 7",
            revertCommand = "settings put system pointer_speed 0",
            icon = Icons.Filled.TouchApp
        ),
        OptimizationTweak(
            id = 17,
            title = "Desativar Backpressure",
            subtitle = "Reduz fila de frames no SurfaceFlinger para menor input lag",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "setprop debug.sf.disable_backpressure 1",
            revertCommand = "setprop debug.sf.disable_backpressure 0",
            icon = Icons.Filled.LayersClear
        ),
        OptimizationTweak(
            id = 18,
            title = "Remover Trava SwapInterval",
            subtitle = "Desabilita espera VSync EGL em buffers gráficos",
            category = OptimizationCategory.DISPLAY_TOUCH,
            applyCommand = "setprop debug.egl.swapinterval 0",
            revertCommand = "setprop debug.egl.swapinterval 1",
            icon = Icons.Filled.Refresh
        ),

        // Sistema & Rede (7 funções)
        OptimizationTweak(
            id = 19,
            title = "Modo Doze Imediato",
            subtitle = "Hiberna serviços ociosos instantaneamente",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "dumpsys deviceidle force-idle",
            revertCommand = "dumpsys deviceidle unforce",
            icon = Icons.Filled.BatterySaver
        ),
        OptimizationTweak(
            id = 20,
            title = "Limpar Cache DNS",
            subtitle = "Renova resolução de rotas para menor latência de rede",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "ndc resolver clearnetdns",
            revertCommand = null,
            icon = Icons.Filled.Dns
        ),
        OptimizationTweak(
            id = 21,
            title = "Otimização TCP/IP",
            subtitle = "Amplia janela inicial TCP (rwnd 60) para pacotes rápidos",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "settings put global tcp_default_init_rwnd 60",
            revertCommand = "settings delete global tcp_default_init_rwnd",
            icon = Icons.Filled.NetworkCheck
        ),
        OptimizationTweak(
            id = 22,
            title = "Desativar Busca Wi-Fi 2º Plano",
            subtitle = "Impede varreduras constantes de rede durante jogos",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "settings put global wifi_scan_always_enabled 0",
            revertCommand = "settings put global wifi_scan_always_enabled 1",
            icon = Icons.Filled.WifiOff
        ),
        OptimizationTweak(
            id = 23,
            title = "Limpar Logs do Sistema",
            subtitle = "Zera o buffer circular do logcat em memória",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "logcat -c",
            revertCommand = null,
            icon = Icons.Filled.DeleteSweep
        ),
        OptimizationTweak(
            id = 24,
            title = "Otimizar Standby Bucket",
            subtitle = "Define prioridade ativa para gerenciamento de energia",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = "am set-standby-bucket --all active",
            revertCommand = null,
            icon = Icons.Filled.Speed
        ),
        OptimizationTweak(
            id = 25,
            title = "Restaurar Padrões de Fábrica",
            subtitle = "Reverte todas as configurações modificadas para o padrão original",
            category = OptimizationCategory.SYSTEM_NET,
            applyCommand = fullRestoreScript,
            revertCommand = null,
            icon = Icons.Filled.RestartAlt,
            isRestoreFactory = true
        )
    )
}
