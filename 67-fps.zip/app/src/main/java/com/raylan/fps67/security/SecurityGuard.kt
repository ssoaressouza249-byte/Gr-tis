package com.raylan.fps67.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.fps67.ui.theme.PureBlack
import com.raylan.fps67.ui.theme.PureWhite
import com.raylan.fps67.ui.theme.TamperDarkRed
import com.raylan.fps67.ui.theme.TamperRed

object SecurityGuard {
    private const val EXPECTED_PACKAGE = "com.raylan.fps67"
    private const val EXPECTED_APP_NAME = "67 FPS"

    fun isAppAuthentic(context: Context): Boolean {
        val packageValid = runCatching {
            context.packageName == EXPECTED_PACKAGE
        }.getOrDefault(false)

        val appNameValid = runCatching {
            val label = context.applicationInfo.loadLabel(context.packageManager).toString()
            label == EXPECTED_APP_NAME
        }.getOrDefault(false)

        return packageValid && appNameValid
    }

    fun launchUninstall(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}

@Composable
fun TamperLockScreen(context: Context) {
    BackHandler(enabled = true) {}

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TamperRed)
            .safeDrawingPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = "Alerta de integridade",
            tint = PureWhite,
            modifier = Modifier.size(72.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "CÓPIA NÃO AUTORIZADA DETECTADA",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.8.sp
            ),
            color = PureWhite,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Este aplicativo foi modificado fora da distribuição oficial do 67 FPS (com.raylan.fps67). Por segurança, todas as funções foram bloqueadas permanentemente.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.92f),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { SecurityGuard.launchUninstall(context) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("tamper_uninstall_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = PureWhite,
                contentColor = PureBlack
            )
        ) {
            Text(
                text = "DESINSTALAR AGORA",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "67 FPS • Criado por Raylan",
            style = MaterialTheme.typography.bodySmall,
            color = TamperDarkRed.copy(alpha = 0.9f).let { PureWhite.copy(alpha = 0.75f) },
            textAlign = TextAlign.Center
        )
    }
}
