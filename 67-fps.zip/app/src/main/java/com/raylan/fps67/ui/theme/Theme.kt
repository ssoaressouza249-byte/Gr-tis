package com.raylan.fps67.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val Fps67ColorScheme = darkColorScheme(
    primary = PureWhite,
    onPrimary = PureBlack,
    primaryContainer = GraphiteElevated,
    onPrimaryContainer = PureWhite,
    secondary = PureWhite,
    onSecondary = PureBlack,
    secondaryContainer = GraphiteSurface,
    onSecondaryContainer = PureWhite,
    tertiary = SilverGray,
    onTertiary = PureBlack,
    background = OledBlack,
    onBackground = PureWhite,
    surface = GraphiteSurface,
    onSurface = PureWhite,
    surfaceVariant = GraphiteElevated,
    onSurfaceVariant = SilverGray,
    outline = HairlineBorder,
    outlineVariant = TranslucentWhiteBorder
)

private val Fps67Shapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun Fps67Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Fps67ColorScheme,
        typography = Fps67Typography,
        shapes = Fps67Shapes,
        content = content
    )
}
