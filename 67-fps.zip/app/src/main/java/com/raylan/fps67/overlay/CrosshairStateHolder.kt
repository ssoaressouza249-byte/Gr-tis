package com.raylan.fps67.overlay

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object CrosshairStateHolder {
    private const val PREFS_NAME = "fps67_crosshair_prefs"
    private const val KEY_STYLE = "style"
    private const val KEY_COLOR = "color"
    private const val KEY_SIZE = "size"
    private const val KEY_STROKE = "stroke"
    private const val KEY_OPACITY = "opacity"
    private const val KEY_OFFSET_X = "offset_x"
    private const val KEY_OFFSET_Y = "offset_y"

    private val _config = MutableStateFlow(CrosshairConfig())
    val config: StateFlow<CrosshairConfig> = _config.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    @Volatile
    private var loaded = false

    fun loadIfNeeded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            runCatching {
                val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val styleName = prefs.getString(KEY_STYLE, CrosshairStyle.CROSS_DOT.name)
                val style = CrosshairStyle.entries.firstOrNull { it.name == styleName }
                    ?: CrosshairStyle.CROSS_DOT
                _config.value = CrosshairConfig(
                    style = style,
                    colorArgb = prefs.getInt(KEY_COLOR, CrosshairColorPreset.PURE_WHITE.argb),
                    sizeDp = prefs.getFloat(KEY_SIZE, 26f).coerceIn(10f, 60f),
                    strokeDp = prefs.getFloat(KEY_STROKE, 2.5f).coerceIn(1f, 6f),
                    opacity = prefs.getFloat(KEY_OPACITY, 0.95f).coerceIn(0.2f, 1.0f),
                    offsetXPx = prefs.getInt(KEY_OFFSET_X, 0),
                    offsetYPx = prefs.getInt(KEY_OFFSET_Y, 0)
                )
            }
            loaded = true
        }
    }

    fun updateConfig(context: Context, transform: (CrosshairConfig) -> CrosshairConfig) {
        loadIfNeeded(context)
        var updated = _config.value
        _config.update { current ->
            updated = transform(current).let { cfg ->
                cfg.copy(
                    sizeDp = cfg.sizeDp.coerceIn(10f, 60f),
                    strokeDp = cfg.strokeDp.coerceIn(1f, 6f),
                    opacity = cfg.opacity.coerceIn(0.2f, 1.0f),
                    offsetXPx = cfg.offsetXPx.coerceIn(-300, 300),
                    offsetYPx = cfg.offsetYPx.coerceIn(-300, 300)
                )
            }
            updated
        }
        persist(context, updated)
    }

    fun setOverlayActive(active: Boolean) {
        _isOverlayActive.value = active
    }

    private fun persist(context: Context, cfg: CrosshairConfig) {
        runCatching {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_STYLE, cfg.style.name)
                .putInt(KEY_COLOR, cfg.colorArgb)
                .putFloat(KEY_SIZE, cfg.sizeDp)
                .putFloat(KEY_STROKE, cfg.strokeDp)
                .putFloat(KEY_OPACITY, cfg.opacity)
                .putInt(KEY_OFFSET_X, cfg.offsetXPx)
                .putInt(KEY_OFFSET_Y, cfg.offsetYPx)
                .apply()
        }
    }
}
