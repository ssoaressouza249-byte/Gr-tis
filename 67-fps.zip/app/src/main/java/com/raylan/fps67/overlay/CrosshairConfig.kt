package com.raylan.fps67.overlay

import androidx.compose.ui.graphics.Color

enum class CrosshairStyle(val label: String) {
    DOT("Ponto"),
    CROSS("Cruz"),
    CIRCLE("Círculo"),
    CROSS_DOT("Cruz + Ponto"),
    TACTICAL("Mira Tática")
}

enum class CrosshairColorPreset(val label: String, val argb: Int) {
    PURE_WHITE("Branco Puro", 0xFFFFFFFF.toInt()),
    NEON_RED("Vermelho Neon", 0xFFFF1744.toInt()),
    LIME_GREEN("Verde Limão", 0xFF00E676.toInt()),
    CYAN("Ciano", 0xFF00E5FF.toInt()),
    YELLOW("Amarelo", 0xFFFFEA00.toInt());

    val composeColor: Color get() = Color(argb)
}

data class CrosshairConfig(
    val style: CrosshairStyle = CrosshairStyle.CROSS_DOT,
    val colorArgb: Int = CrosshairColorPreset.PURE_WHITE.argb,
    val sizeDp: Float = 26f,
    val strokeDp: Float = 2.5f,
    val opacity: Float = 0.95f,
    val offsetXPx: Int = 0,
    val offsetYPx: Int = 0
)
