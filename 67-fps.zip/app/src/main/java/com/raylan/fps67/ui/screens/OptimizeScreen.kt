package com.raylan.fps67.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.fps67.R
import com.raylan.fps67.data.OptimizationCategory
import com.raylan.fps67.data.OptimizationTweak
import com.raylan.fps67.shizuku.ShizukuStatus
import com.raylan.fps67.ui.components.MonochromeCard
import com.raylan.fps67.ui.components.ShizukuStatusBadge
import com.raylan.fps67.ui.theme.GraphiteElevated
import com.raylan.fps67.ui.theme.GraphiteSurface
import com.raylan.fps67.ui.theme.HairlineBorder
import com.raylan.fps67.ui.theme.OledBlack
import com.raylan.fps67.ui.theme.PureBlack
import com.raylan.fps67.ui.theme.PureWhite
import com.raylan.fps67.ui.theme.SilverGray
import com.raylan.fps67.ui.theme.TranslucentWhiteBorder

@Composable
fun OptimizeScreen(
    uiState: OptimizeUiState,
    tweaks: List<OptimizationTweak>,
    shizukuStatus: ShizukuStatus,
    onShizukuBadgeClick: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (OptimizationCategory) -> Unit,
    onToggleTweak: (OptimizationTweak, Boolean) -> Unit,
    onInspectTweak: (OptimizationTweak?) -> Unit,
    onCopyFeedback: (String) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OledBlack)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "67 FPS",
                        style = MaterialTheme.typography.headlineLarge,
                        color = PureWhite
                    )
                    Text(
                        text = "SHIZUKU SHELL ENGINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverGray
                    )
                }

                ShizukuStatusBadge(
                    status = shizukuStatus,
                    onClick = onShizukuBadgeClick
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick device telemetry strip
            MonochromeCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PhoneAndroid,
                            contentDescription = "Modelo do aparelho",
                            tint = PureWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = uiState.telemetry.modelName,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            color = PureWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Memory,
                            contentDescription = "Memória RAM livre",
                            tint = SilverGray,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${uiState.telemetry.freeRamMb} MB livre",
                            style = MaterialTheme.typography.labelSmall,
                            color = PureWhite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search bar
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_tweak_input"),
                placeholder = {
                    Text(
                        text = "Buscar função...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SilverGray
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Buscar",
                        tint = SilverGray
                    )
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Limpar busca",
                                tint = PureWhite
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = GraphiteSurface,
                    unfocusedContainerColor = GraphiteSurface,
                    focusedBorderColor = PureWhite,
                    unfocusedBorderColor = HairlineBorder,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                    cursorColor = PureWhite
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4 Filter Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OptimizationCategory.entries.forEach { category ->
                    val selected = category == uiState.selectedCategory
                    Surface(
                        onClick = { onCategorySelect(category) },
                        modifier = Modifier.testTag("filter_pill_${category.name.lowercase()}"),
                        shape = RoundedCornerShape(999.dp),
                        color = if (selected) PureWhite else GraphiteSurface,
                        border = BorderStroke(
                            1.dp,
                            if (selected) PureWhite else TranslucentWhiteBorder
                        )
                    ) {
                        Text(
                            text = category.label,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (selected) PureBlack else SilverGray
                        )
                    }
                }
            }
        }

        // Tweaks List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("tweaks_list"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (tweaks.isEmpty()) {
                item {
                    MonochromeCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = SilverGray,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Nenhuma função encontrada",
                                style = MaterialTheme.typography.titleMedium,
                                color = PureWhite
                            )
                            Text(
                                text = "Tente outro termo ou limpe o filtro atual.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SilverGray
                            )
                        }
                    }
                }
            } else {
                items(tweaks, key = { it.id }) { tweak ->
                    val isChecked = uiState.activeTweakIds.contains(tweak.id)
                    TweakCard(
                        tweak = tweak,
                        checked = isChecked,
                        enabled = !uiState.isBatchProcessing,
                        onToggle = { enable -> onToggleTweak(tweak, enable) },
                        onInfoClick = { onInspectTweak(tweak) }
                    )
                }
            }

            item {
                Text(
                    text = stringResource(R.string.official_credits),
                    style = MaterialTheme.typography.bodySmall,
                    color = SilverGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp)
                )
            }
        }
    }

    uiState.inspectedTweak?.let { tweak ->
        TweakCommandDialog(
            tweak = tweak,
            onDismiss = { onInspectTweak(null) },
            onCopy = {
                runCatching {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("ADB Command", tweak.applyCommand))
                }
                onCopyFeedback("Comando copiado para a área de transferência.")
            }
        )
    }
}

@Composable
private fun TweakCard(
    tweak: OptimizationTweak,
    checked: Boolean,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    onInfoClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tweak_card_${tweak.id}"),
        shape = RoundedCornerShape(16.dp),
        color = GraphiteSurface,
        border = BorderStroke(
            width = 1.dp,
            color = if (checked) PureWhite.copy(alpha = 0.55f) else TranslucentWhiteBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (checked) PureWhite else GraphiteElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tweak.icon,
                    contentDescription = tweak.title,
                    tint = if (checked) PureBlack else PureWhite,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${tweak.id}. ${tweak.title}",
                    style = MaterialTheme.typography.titleMedium,
                    color = PureWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tweak.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = SilverGray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onInfoClick,
                modifier = Modifier.testTag("tweak_info_${tweak.id}")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = "Ver comando ADB de ${tweak.title}",
                    tint = SilverGray,
                    modifier = Modifier.size(20.dp)
                )
            }

            if (tweak.isRestoreFactory) {
                Button(
                    onClick = { onToggle(true) },
                    enabled = enabled,
                    modifier = Modifier.testTag("tweak_restore_button"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PureWhite,
                        contentColor = PureBlack
                    )
                ) {
                    Text(
                        text = "Restaurar",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            } else {
                Switch(
                    checked = checked,
                    onCheckedChange = onToggle,
                    enabled = enabled,
                    modifier = Modifier.testTag("tweak_switch_${tweak.id}"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureBlack,
                        checkedTrackColor = PureWhite,
                        checkedBorderColor = PureWhite,
                        uncheckedThumbColor = SilverGray,
                        uncheckedTrackColor = GraphiteElevated,
                        uncheckedBorderColor = HairlineBorder
                    )
                )
            }
        }
    }
}

@Composable
private fun TweakCommandDialog(
    tweak: OptimizationTweak,
    onDismiss: () -> Unit,
    onCopy: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GraphiteSurface,
        titleContentColor = PureWhite,
        textContentColor = SilverGray,
        title = {
            Text(
                text = tweak.title,
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = tweak.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SilverGray
                )
                Text(
                    text = "COMANDO ADB (UID 2000):",
                    style = MaterialTheme.typography.labelSmall,
                    color = PureWhite
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = OledBlack,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Text(
                        text = tweak.applyCommand,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = PureWhite
                    )
                }
                if (tweak.revertCommand != null) {
                    Text(
                        text = "REVERSÃO:",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverGray
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = OledBlack,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Text(
                            text = tweak.revertCommand,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                            color = SilverGray
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("FECHAR", color = PureWhite, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onCopy) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = null,
                    tint = SilverGray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("COPIAR", color = SilverGray)
            }
        }
    )
}
