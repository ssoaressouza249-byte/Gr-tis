package com.raylan.fps67

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raylan.fps67.security.SecurityGuard
import com.raylan.fps67.security.TamperLockScreen
import com.raylan.fps67.shizuku.ShizukuManager
import com.raylan.fps67.ui.components.MasterBoostFooter
import com.raylan.fps67.ui.screens.CrosshairScreen
import com.raylan.fps67.ui.screens.MainTab
import com.raylan.fps67.ui.screens.MainViewModel
import com.raylan.fps67.ui.screens.OptimizeScreen
import com.raylan.fps67.ui.screens.SystemScreen
import com.raylan.fps67.ui.theme.Fps67Theme
import com.raylan.fps67.ui.theme.GraphiteElevated
import com.raylan.fps67.ui.theme.OledBlack
import com.raylan.fps67.ui.theme.PureWhite

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        ShizukuManager.initialize()

        setContent {
            Fps67Theme {
                val context = LocalContext.current
                val isAuthentic = remember { SecurityGuard.isAppAuthentic(context) }

                if (!isAuthentic) {
                    TamperLockScreen(context = context)
                } else {
                    Fps67AppContent()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ShizukuManager.refreshState()
    }
}

@Composable
private fun Fps67AppContent(
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val optimizeState by viewModel.optimizeState.collectAsStateWithLifecycle()
    val filteredTweaks by viewModel.filteredTweaks.collectAsStateWithLifecycle()
    val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
    val shellLogs by viewModel.shellLogs.collectAsStateWithLifecycle()
    val crosshairConfig by viewModel.crosshairConfig.collectAsStateWithLifecycle()
    val isOverlayActive by viewModel.isOverlayActive.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(
            message = msg,
            duration = SnackbarDuration.Short
        )
        viewModel.clearMessage()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(OledBlack),
        containerColor = OledBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = GraphiteElevated,
                    contentColor = PureWhite
                )
            }
        },
        bottomBar = {
            MasterBoostFooter(
                selectedTab = selectedTab,
                onSelectTab = viewModel::selectTab,
                activeCount = optimizeState.activeCount,
                totalCount = 25,
                isMasterActive = optimizeState.isMasterBoostActive,
                isBatchProcessing = optimizeState.isBatchProcessing,
                batchProgressText = optimizeState.batchProgressText,
                onMasterBoostClick = viewModel::toggleMasterBoost
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(OledBlack)
                .statusBarsPadding()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
            ) {
                when (selectedTab) {
                    MainTab.OPTIMIZE -> OptimizeScreen(
                        uiState = optimizeState,
                        tweaks = filteredTweaks,
                        shizukuStatus = shizukuStatus,
                        onShizukuBadgeClick = viewModel::connectOrAuthorizeShizuku,
                        onSearchQueryChange = viewModel::updateSearchQuery,
                        onCategorySelect = viewModel::selectCategory,
                        onToggleTweak = viewModel::toggleTweak,
                        onInspectTweak = viewModel::showTweakInfo,
                        onCopyFeedback = viewModel::showMessage
                    )

                    MainTab.CROSSHAIR -> CrosshairScreen(
                        config = crosshairConfig,
                        isOverlayActive = isOverlayActive,
                        onToggleOverlay = { viewModel.toggleCrosshairOverlay(context) },
                        onSelectStyle = viewModel::setCrosshairStyle,
                        onSelectColor = viewModel::setCrosshairColor,
                        onSizeChange = viewModel::setCrosshairSize,
                        onStrokeChange = viewModel::setCrosshairStroke,
                        onOpacityChange = viewModel::setCrosshairOpacity,
                        onNudgeOffset = viewModel::nudgeCrosshairOffset,
                        onCenterOffset = viewModel::centerCrosshair
                    )

                    MainTab.SYSTEM -> SystemScreen(
                        shizukuStatus = shizukuStatus,
                        logs = shellLogs,
                        isBatchProcessing = optimizeState.isBatchProcessing,
                        onAuthorizeShizuku = viewModel::connectOrAuthorizeShizuku,
                        onTestIdentity = viewModel::testShizukuIdentity,
                        onRestoreAll = viewModel::restoreAllDefaults,
                        onClearLogs = viewModel::clearLogs
                    )
                }
            }
        }
    }
}
