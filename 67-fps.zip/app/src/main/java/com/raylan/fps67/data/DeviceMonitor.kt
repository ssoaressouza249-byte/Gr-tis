package com.raylan.fps67.data

import android.app.ActivityManager
import android.content.Context
import android.os.Build

data class DeviceTelemetry(
    val modelName: String = "Android",
    val freeRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val androidVersion: String = Build.VERSION.RELEASE ?: "14+"
) {
    val usedPercent: Int
        get() = if (totalRamMb > 0L) {
            (((totalRamMb - freeRamMb).toFloat() / totalRamMb.toFloat()) * 100f).toInt().coerceIn(0, 100)
        } else {
            0
        }
}

object DeviceMonitor {
    fun readTelemetry(context: Context): DeviceTelemetry {
        val model = runCatching {
            val manufacturer = Build.MANUFACTURER.orEmpty().trim()
            val modelName = Build.MODEL.orEmpty().trim()
            if (modelName.startsWith(manufacturer, ignoreCase = true)) {
                modelName
            } else {
                "$manufacturer $modelName".trim()
            }.ifEmpty { "Android Device" }
        }.getOrDefault("Android Device")

        var freeMb = 0L
        var totalMb = 0L

        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                freeMb = memInfo.availMem / (1024L * 1024L)
                totalMb = memInfo.totalMem / (1024L * 1024L)
            }
        }

        return DeviceTelemetry(
            modelName = model,
            freeRamMb = freeMb,
            totalRamMb = totalMb
        )
    }
}
