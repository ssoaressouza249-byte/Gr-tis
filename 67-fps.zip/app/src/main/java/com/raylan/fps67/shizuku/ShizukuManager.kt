package com.raylan.fps67.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ShizukuStatus(
    val isBinderAlive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val uid: Int? = null,
    val statusMessage: String = "Aguardando conexão com Shizuku"
) {
    val isReady: Boolean get() = isBinderAlive && isPermissionGranted
}

data class ShellLogEntry(
    val id: Long,
    val timestamp: String,
    val command: String,
    val success: Boolean,
    val output: String
)

object ShizukuManager {
    private const val REQUEST_CODE_SHIZUKU = 1001
    private const val MAX_LOG_ENTRIES = 60

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<ShellLogEntry>>(emptyList())
    val logs: StateFlow<List<ShellLogEntry>> = _logs.asStateFlow()

    @Volatile
    private var initialized = false
    private var logSequence = 0L

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshState("Shizuku binder conectado")
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _status.update {
            it.copy(
                isBinderAlive = false,
                isPermissionGranted = false,
                uid = null,
                statusMessage = "Shizuku desconectado"
            )
        }
        appendLog("binder", false, "Serviço Shizuku encerrado ou indisponível.")
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                refreshState(
                    if (granted) "Permissão Shizuku concedida" else "Permissão Shizuku negada"
                )
                appendLog(
                    "shizuku_permission",
                    granted,
                    if (granted) "Autorizado com sucesso (UID ${runCatching { Shizuku.getUid() }.getOrNull() ?: "?"})"
                    else "Usuário negou a permissão do Shizuku."
                )
            }
        }

    fun initialize() {
        if (initialized) {
            refreshState()
            return
        }
        synchronized(this) {
            if (initialized) {
                refreshState()
                return
            }
            runCatching {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionResultListener)
                initialized = true
            }.onFailure { error ->
                appendLog("init", false, "Falha ao registrar listeners Shizuku: ${error.message}")
            }
            refreshState()
        }
    }

    fun release() {
        if (!initialized) return
        synchronized(this) {
            runCatching {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(permissionResultListener)
                initialized = false
            }
        }
    }

    fun refreshState(customMessage: String? = null) {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = if (binderAlive) {
            runCatching {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
        } else {
            false
        }
        val uid = if (binderAlive) runCatching { Shizuku.getUid() }.getOrNull() else null

        val message = customMessage ?: when {
            !binderAlive -> "Shizuku inativo — abra o app Shizuku e inicie o serviço"
            !granted -> "Shizuku ativo — toque para autorizar o 67 FPS"
            else -> "Conectado via Shizuku (UID ${uid ?: 2000})"
        }

        _status.value = ShizukuStatus(
            isBinderAlive = binderAlive,
            isPermissionGranted = granted,
            uid = uid,
            statusMessage = message
        )
    }

    fun connectOrAuthorize() {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!binderAlive) {
            refreshState("Shizuku não detectado. Inicie o serviço Shizuku primeiro.")
            appendLog(
                "pingBinder",
                false,
                "Shizuku binder não respondeu. Verifique se o Shizuku está em execução."
            )
            return
        }

        val hasPermission = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

        if (!hasPermission) {
            runCatching {
                Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
            }.onFailure { error ->
                appendLog("requestPermission", false, "Erro ao solicitar permissão: ${error.message}")
            }
        } else {
            refreshState("Shizuku já está conectado e autorizado")
            appendLog("status", true, "Shizuku pronto (UID ${runCatching { Shizuku.getUid() }.getOrNull() ?: 2000}).")
        }
    }

    suspend fun runCommand(cmd: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!binderAlive) {
            val msg = "Shizuku inativo: não foi possível executar '$cmd'"
            appendLog(cmd, false, msg)
            refreshState()
            return@withContext false to msg
        }

        val hasPermission = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

        if (!hasPermission) {
            val msg = "Permissão Shizuku pendente: autorize o app antes de executar '$cmd'"
            appendLog(cmd, false, msg)
            refreshState()
            return@withContext false to msg
        }

        val executionResult = runCatching {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
            }

            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", cmd),
                null,
                null
            ) as Process

            coroutineScope {
                val stdoutDeferred = async {
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        reader.readText().trim()
                    }
                }
                val stderrDeferred = async {
                    BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                        reader.readText().trim()
                    }
                }
                val stdout = stdoutDeferred.await()
                val stderr = stderrDeferred.await()
                val exitCode = process.waitFor()

                val combined = buildString {
                    if (stdout.isNotEmpty()) append(stdout)
                    if (stderr.isNotEmpty()) {
                        if (isNotEmpty()) append("\n")
                        append(stderr)
                    }
                    if (isEmpty()) {
                        append(if (exitCode == 0) "OK (exit 0)" else "Erro (exit $exitCode)")
                    }
                }
                (exitCode == 0) to combined
            }
        }

        val pair = executionResult.getOrElse { throwable ->
            false to "Exceção: ${throwable.message ?: throwable.javaClass.simpleName}"
        }

        appendLog(cmd, pair.first, pair.second)
        pair
    }

    suspend fun testIdentity(): Pair<Boolean, String> = runCommand("id")

    fun clearLogs() {
        _logs.value = emptyList()
    }

    private fun appendLog(command: String, success: Boolean, output: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = ShellLogEntry(
            id = ++logSequence,
            timestamp = time,
            command = command,
            success = success,
            output = output
        )
        _logs.update { current ->
            (listOf(entry) + current).take(MAX_LOG_ENTRIES)
        }
    }
}
