package com.raylan.fps67.ui.theme

import androidx.compose.ui.graphics.Color

val OledBlack = Color(0xFF000000)
val GraphiteSurface = Color(0xFF111113)
val GraphiteElevated = Color(0xFF18181B)
val HairlineBorder = Color(0xFF2A2A2E)
val TranslucentWhiteBorder = Color(0x26FFFFFF) // 15% white
val PureWhite = Color(0xFFFFFFFF)
val PureBlack = Color(0xFF000000)
val SilverGray = Color(0xFFA1A1AA)
val MutedGray = Color(0xFF71717A)
val TamperRed = Color(0xFFD50000)
val TamperDarkRed = Color(0xFF8E0000)
