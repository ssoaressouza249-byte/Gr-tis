package com.raylan.fps67.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.fps67.shizuku.ShizukuStatus
import com.raylan.fps67.ui.screens.MainTab
import com.raylan.fps67.ui.theme.GraphiteElevated
import com.raylan.fps67.ui.theme.GraphiteSurface
import com.raylan.fps67.ui.theme.HairlineBorder
import com.raylan.fps67.ui.theme.OledBlack
import com.raylan.fps67.ui.theme.PureBlack
import com.raylan.fps67.ui.theme.PureWhite
import com.raylan.fps67.ui.theme.SilverGray
import com.raylan.fps67.ui.theme.TranslucentWhiteBorder

@Composable
fun ShizukuStatusBadge(
    status: ShizukuStatus,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (status.isReady) PureWhite else GraphiteElevated,
        label = "badgeBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (status.isReady) PureBlack else PureWhite,
        label = "badgeFg"
    )

    Surface(
        onClick = onClick,
        modifier = modifier.testTag("shizuku_status_badge"),
        shape = RoundedCornerShape(999.dp),
        color = bgColor,
        border = BorderStroke(1.dp, if (status.isReady) PureWhite else TranslucentWhiteBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (status.isReady) PureBlack else SilverGray)
            )
            Text(
                text = if (status.isReady) "SHIZUKU • ATIVO" else "TOQUE P/ CONECTAR",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = contentColor
            )
        }
    }
}

@Composable
fun MasterBoostFooter(
    selectedTab: MainTab,
    onSelectTab: (MainTab) -> Unit,
    activeCount: Int,
    totalCount: Int,
    isMasterActive: Boolean,
    isBatchProcessing: Boolean,
    batchProgressText: String?,
    onMasterBoostClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(OledBlack)
    ) {
        HorizontalDivider(thickness = 1.dp, color = HairlineBorder)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Button(
                onClick = onMasterBoostClick,
                enabled = !isBatchProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("master_boost_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PureWhite,
                    contentColor = PureBlack,
                    disabledContainerColor = GraphiteElevated,
                    disabledContentColor = SilverGray
                ),
                border = if (isMasterActive) BorderStroke(1.dp, PureWhite) else null
            ) {
                if (isBatchProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = PureWhite
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "APLICANDO ${batchProgressText ?: "..."}",
                        style = MaterialTheme.typography.labelLarge
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.PowerSettingsNew,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val prefix = if (isMasterActive) "DESATIVAR 67 FPS BOOST" else "ATIVAR 67 FPS BOOST"
                    Text(
                        text = "$prefix ($activeCount/$totalCount)",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black)
                    )
                }
            }
        }

        HorizontalDivider(thickness = 1.dp, color = HairlineBorder)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OledBlack)
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MainTab.entries.forEach { tab ->
                val isSelected = tab == selectedTab
                val icon = when (tab) {
                    MainTab.OPTIMIZE -> if (isSelected) Icons.Filled.Bolt else Icons.Outlined.Bolt
                    MainTab.CROSSHAIR -> if (isSelected) Icons.Filled.CenterFocusStrong else Icons.Outlined.CenterFocusStrong
                    MainTab.SYSTEM -> if (isSelected) Icons.Filled.Terminal else Icons.Outlined.Terminal
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectTab(tab) }
                        .padding(vertical = 6.dp)
                        .testTag("nav_tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (isSelected) PureWhite else Color.Transparent)
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) PureBlack else SilverGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Default,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = if (isSelected) PureWhite else SilverGray
                    )
                }
            }
        }
    }
}

@Composable
fun MonochromeCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TranslucentWhiteBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        color = GraphiteSurface,
        content = content
    )
}
