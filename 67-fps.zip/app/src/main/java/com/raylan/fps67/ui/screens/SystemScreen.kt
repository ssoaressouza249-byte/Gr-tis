package com.raylan.fps67.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.raylan.fps67.R
import com.raylan.fps67.shizuku.ShellLogEntry
import com.raylan.fps67.shizuku.ShizukuStatus
import com.raylan.fps67.ui.components.MonochromeCard
import com.raylan.fps67.ui.theme.GraphiteElevated
import com.raylan.fps67.ui.theme.HairlineBorder
import com.raylan.fps67.ui.theme.OledBlack
import com.raylan.fps67.ui.theme.PureBlack
import com.raylan.fps67.ui.theme.PureWhite
import com.raylan.fps67.ui.theme.SilverGray
import com.raylan.fps67.ui.theme.TranslucentWhiteBorder

@Composable
fun SystemScreen(
    shizukuStatus: ShizukuStatus,
    logs: List<ShellLogEntry>,
    isBatchProcessing: Boolean,
    onAuthorizeShizuku: () -> Unit,
    onTestIdentity: () -> Unit,
    onRestoreAll: () -> Unit,
    onClearLogs: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OledBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Sistema & Shizuku",
            style = MaterialTheme.typography.headlineSmall,
            color = PureWhite
        )

        // Shizuku Connection Card
        MonochromeCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (shizukuStatus.isReady) Icons.Filled.VerifiedUser else Icons.Filled.Security,
                        contentDescription = "Status Shizuku",
                        tint = PureWhite,
                        modifier = Modifier.size(22.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (shizukuStatus.isReady) "Shizuku Conectado" else "Conexão Shizuku",
                            style = MaterialTheme.typography.titleMedium,
                            color = PureWhite
                        )
                        Text(
                            text = shizukuStatus.statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = SilverGray
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onAuthorizeShizuku,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("authorize_shizuku_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PureWhite,
                            contentColor = PureBlack
                        )
                    ) {
                        Text(
                            text = if (shizukuStatus.isReady) "CONECTADO" else "CONECTAR / AUTORIZAR",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    OutlinedButton(
                        onClick = onTestIdentity,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("test_id_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, TranslucentWhiteBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Terminal,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Testar id",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }

        // Restore All Button Card
        OutlinedButton(
            onClick = onRestoreAll,
            enabled = !isBatchProcessing,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("system_restore_all_button"),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.5f)),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = GraphiteElevated,
                contentColor = PureWhite
            )
        ) {
            Icon(
                imageVector = Icons.Filled.RestartAlt,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "RESTAURAR TUDO",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Mini Console Log in Monospace
        MonochromeCard {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CONSOLE SHIZUKU (ADB SHELL)",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverGray
                    )
                    if (logs.isNotEmpty()) {
                        TextButton(
                            onClick = onClearLogs,
                            modifier = Modifier.testTag("clear_logs_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "Limpar console",
                                tint = SilverGray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Limpar", color = SilverGray, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 140.dp, max = 260.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = OledBlack,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    if (logs.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "$ aguardando comandos...",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = SilverGray
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            logs.forEachIndexed { idx, entry ->
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "[${entry.timestamp}] $ ${entry.command}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = PureWhite
                                    )
                                    Text(
                                        text = "${if (entry.success) "→" else "✕"} ${entry.output}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace
                                        ),
                                        color = SilverGray
                                    )
                                }
                                if (idx < logs.lastIndex) {
                                    HorizontalDivider(color = HairlineBorder, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Discreet PRO version card
        MonochromeCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "VERSÃO COMPLETA",
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverGray
                )
                Text(
                    text = "Quer 64+ funções, Satoru Gojo flutuante e desbloqueio extremo de 120 FPS? Conheça o NEXGT / FF Boost PRO",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = PureWhite
                )
            }
        }

        Text(
            text = stringResource(R.string.official_credits),
            style = MaterialTheme.typography.bodySmall,
            color = SilverGray,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        )
    }
}
