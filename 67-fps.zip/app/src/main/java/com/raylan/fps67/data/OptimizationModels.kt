package com.raylan.fps67.data

import androidx.compose.ui.graphics.vector.ImageVector

enum class OptimizationCategory(val label: String) {
    ALL("Todas (25)"),
    PERFORMANCE("Desempenho"),
    DISPLAY_TOUCH("Tela & Toque"),
    SYSTEM_NET("Sistema & Rede")
}

data class OptimizationTweak(
    val id: Int,
    val title: String,
    val subtitle: String,
    val category: OptimizationCategory,
    val applyCommand: String,
    val revertCommand: String? = null,
    val icon: ImageVector,
    val isRestoreFactory: Boolean = false
)
