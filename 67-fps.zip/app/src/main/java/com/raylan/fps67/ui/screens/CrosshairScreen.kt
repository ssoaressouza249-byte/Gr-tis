package com.raylan.fps67.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.raylan.fps67.overlay.CrosshairColorPreset
import com.raylan.fps67.overlay.CrosshairConfig
import com.raylan.fps67.overlay.CrosshairRenderer
import com.raylan.fps67.overlay.CrosshairStyle
import com.raylan.fps67.ui.components.MonochromeCard
import com.raylan.fps67.ui.theme.GraphiteElevated
import com.raylan.fps67.ui.theme.GraphiteSurface
import com.raylan.fps67.ui.theme.HairlineBorder
import com.raylan.fps67.ui.theme.OledBlack
import com.raylan.fps67.ui.theme.PureBlack
import com.raylan.fps67.ui.theme.PureWhite
import com.raylan.fps67.ui.theme.SilverGray
import com.raylan.fps67.ui.theme.TranslucentWhiteBorder
import kotlin.math.roundToInt

@Composable
fun CrosshairScreen(
    config: CrosshairConfig,
    isOverlayActive: Boolean,
    onToggleOverlay: () -> Unit,
    onSelectStyle: (CrosshairStyle) -> Unit,
    onSelectColor: (CrosshairColorPreset) -> Unit,
    onSizeChange: (Float) -> Unit,
    onStrokeChange: (Float) -> Unit,
    onOpacityChange: (Float) -> Unit,
    onNudgeOffset: (Int, Int) -> Unit,
    onCenterOffset: () -> Unit
) {
    val context = LocalContext.current

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onToggleOverlay()
    }

    val handleOverlayToggle = {
        if (!isOverlayActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                onToggleOverlay()
            }
        } else {
            onToggleOverlay()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OledBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Mira Flutuante",
                    style = MaterialTheme.typography.headlineSmall,
                    color = PureWhite
                )
                Text(
                    text = "Overlay tático sem bloqueio de toque",
                    style = MaterialTheme.typography.bodySmall,
                    color = SilverGray
                )
            }

            Surface(
                shape = RoundedCornerShape(999.dp),
                color = if (isOverlayActive) PureWhite else GraphiteElevated,
                border = BorderStroke(1.dp, TranslucentWhiteBorder)
            ) {
                Text(
                    text = if (isOverlayActive) "ATIVA" else "INATIVA",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (isOverlayActive) PureBlack else SilverGray
                )
            }
        }

        // Live Checkerboard Preview Panel
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(176.dp)
                .border(1.dp, TranslucentWhiteBorder, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            color = GraphiteSurface
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cellSize = 18.dp.toPx()
                    val cols = (size.width / cellSize).toInt() + 1
                    val rows = (size.height / cellSize).toInt() + 1
                    val darkA = Color(0xFF0A0A0C)
                    val darkB = Color(0xFF151518)

                    for (r in 0 until rows) {
                        for (c in 0 until cols) {
                            drawRect(
                                color = if ((r + c) % 2 == 0) darkA else darkB,
                                topLeft = Offset(c * cellSize, r * cellSize),
                                size = Size(cellSize, cellSize)
                            )
                        }
                    }

                    // Subtle center alignment guide lines
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(size.width / 2f, 0f),
                        end = Offset(size.width / 2f, size.height),
                        strokeWidth = 1f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(0f, size.height / 2f),
                        end = Offset(size.width, size.height / 2f),
                        strokeWidth = 1f
                    )

                    val previewCenterX = (size.width / 2f + (config.offsetXPx * 0.45f))
                        .coerceIn(24f, size.width - 24f)
                    val previewCenterY = (size.height / 2f + (config.offsetYPx * 0.45f))
                        .coerceIn(24f, size.height - 24f)

                    drawIntoCanvas { canvas ->
                        CrosshairRenderer.draw(
                            canvas = canvas.nativeCanvas,
                            centerX = previewCenterX,
                            centerY = previewCenterY,
                            density = density,
                            config = config
                        )
                    }
                }

                Text(
                    text = "PRÉVIA AO VIVO • X:${config.offsetXPx} Y:${config.offsetYPx}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverGray,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                )
            }
        }

        // Main Toggle Button
        Button(
            onClick = handleOverlayToggle,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("toggle_overlay_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = PureWhite,
                contentColor = PureBlack
            )
        ) {
            Icon(
                imageVector = Icons.Filled.CenterFocusStrong,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isOverlayActive) "DESATIVAR MIRA FLUTUANTE" else "ATIVAR MIRA FLUTUANTE",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black)
            )
        }

        // Style Picker
        MonochromeCard {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ESTILO DA MIRA",
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverGray
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CrosshairStyle.entries.forEach { style ->
                        val selected = style == config.style
                        Surface(
                            onClick = { onSelectStyle(style) },
                            modifier = Modifier.testTag("crosshair_style_${style.name.lowercase()}"),
                            shape = RoundedCornerShape(999.dp),
                            color = if (selected) PureWhite else GraphiteElevated,
                            border = BorderStroke(1.dp, if (selected) PureWhite else HairlineBorder)
                        ) {
                            Text(
                                text = style.label,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (selected) PureBlack else PureWhite
                            )
                        }
                    }
                }
            }
        }

        // Color Picker
        MonochromeCard {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val activePresetName = CrosshairColorPreset.entries
                    .firstOrNull { it.argb == config.colorArgb }?.label ?: "Personalizada"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "COR DA MIRA",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverGray
                    )
                    Text(
                        text = activePresetName,
                        style = MaterialTheme.typography.labelSmall,
                        color = PureWhite
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CrosshairColorPreset.entries.forEach { preset ->
                        val selected = preset.argb == config.colorArgb
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .border(
                                    width = if (selected) 2.5.dp else 1.dp,
                                    color = if (selected) PureWhite else HairlineBorder,
                                    shape = CircleShape
                                )
                                .padding(5.dp)
                                .clip(CircleShape)
                                .background(preset.composeColor)
                                .clickable { onSelectColor(preset) }
                                .testTag("crosshair_color_${preset.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = preset.label,
                                    tint = PureBlack,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sliders (Size, Stroke, Opacity)
        MonochromeCard {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CrosshairSliderRow(
                    label = "Tamanho",
                    valueText = "${config.sizeDp.roundToInt()} dp",
                    value = config.sizeDp,
                    range = 10f..60f,
                    onValueChange = onSizeChange,
                    testTag = "slider_crosshair_size"
                )
                CrosshairSliderRow(
                    label = "Espessura do traço",
                    valueText = "${String.format("%.1f", config.strokeDp)} dp",
                    value = config.strokeDp,
                    range = 1f..6f,
                    onValueChange = onStrokeChange,
                    testTag = "slider_crosshair_stroke"
                )
                CrosshairSliderRow(
                    label = "Opacidade",
                    valueText = "${(config.opacity * 100f).roundToInt()}%",
                    value = config.opacity,
                    range = 0.2f..1.0f,
                    onValueChange = onOpacityChange,
                    testTag = "slider_crosshair_opacity"
                )
            }
        }

        // Fine Position Alignment Controls
        MonochromeCard {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AJUSTE FINO DE POSIÇÃO",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverGray
                    )
                    Text(
                        text = "X: ${config.offsetXPx}px • Y: ${config.offsetYPx}px",
                        style = MaterialTheme.typography.labelSmall,
                        color = PureWhite
                    )
                }

                // D-pad style fine alignment
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PositionArrowButton(
                        icon = Icons.Filled.KeyboardArrowUp,
                        contentDescription = "Mover mira para cima",
                        onClick = { onNudgeOffset(0, -4) },
                        testTag = "nudge_up"
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PositionArrowButton(
                            icon = Icons.Filled.KeyboardArrowLeft,
                            contentDescription = "Mover mira para esquerda",
                            onClick = { onNudgeOffset(-4, 0) },
                            testTag = "nudge_left"
                        )
                        OutlinedButton(
                            onClick = onCenterOffset,
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("nudge_center"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, TranslucentWhiteBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MyLocation,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Centralizar",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        PositionArrowButton(
                            icon = Icons.Filled.KeyboardArrowRight,
                            contentDescription = "Mover mira para direita",
                            onClick = { onNudgeOffset(4, 0) },
                            testTag = "nudge_right"
                        )
                    }
                    PositionArrowButton(
                        icon = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Mover mira para baixo",
                        onClick = { onNudgeOffset(0, 4) },
                        testTag = "nudge_down"
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun CrosshairSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = PureWhite
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelSmall,
                color = SilverGray
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.testTag(testTag),
            colors = SliderDefaults.colors(
                thumbColor = PureWhite,
                activeTrackColor = PureWhite,
                inactiveTrackColor = HairlineBorder
            )
        )
    }
}

@Composable
private fun PositionArrowButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .size(48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = GraphiteElevated,
        border = BorderStroke(1.dp, TranslucentWhiteBorder)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = PureWhite,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
