package com.raylan.fps67.overlay

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.roundToInt

object CrosshairRenderer {

    fun draw(
        canvas: Canvas,
        centerX: Float,
        centerY: Float,
        density: Float,
        config: CrosshairConfig
    ) {
        val alphaInt = (config.opacity.coerceIn(0.2f, 1.0f) * 255f).roundToInt()
        val baseColor = config.colorArgb
        val effectiveColor = Color.argb(
            alphaInt,
            Color.red(baseColor),
            Color.green(baseColor),
            Color.blue(baseColor)
        )

        val sizePx = config.sizeDp * density
        val halfSize = sizePx / 2f
        val strokePx = config.strokeDp * density

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = effectiveColor
            style = Paint.Style.STROKE
            strokeWidth = strokePx
            strokeCap = Paint.Cap.ROUND
        }

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = effectiveColor
            style = Paint.Style.FILL
        }

        val outlineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((alphaInt * 0.55f).roundToInt(), 0, 0, 0)
            style = Paint.Style.STROKE
            strokeWidth = strokePx + (1.5f * density)
            strokeCap = Paint.Cap.ROUND
        }

        when (config.style) {
            CrosshairStyle.DOT -> {
                val radius = (sizePx * 0.16f).coerceAtLeast(strokePx * 0.9f)
                canvas.drawCircle(centerX, centerY, radius + density, Paint(outlineStrokePaint).apply {
                    style = Paint.Style.FILL
                })
                canvas.drawCircle(centerX, centerY, radius, fillPaint)
            }

            CrosshairStyle.CROSS -> {
                val gap = (sizePx * 0.18f).coerceAtLeast(strokePx * 1.4f)
                drawCrossLines(canvas, centerX, centerY, gap, halfSize, outlineStrokePaint)
                drawCrossLines(canvas, centerX, centerY, gap, halfSize, strokePaint)
            }

            CrosshairStyle.CIRCLE -> {
                val radius = halfSize * 0.85f
                canvas.drawCircle(centerX, centerY, radius, outlineStrokePaint)
                canvas.drawCircle(centerX, centerY, radius, strokePaint)
                val dotRadius = (strokePx * 0.75f).coerceAtLeast(1.5f * density)
                canvas.drawCircle(centerX, centerY, dotRadius, fillPaint)
            }

            CrosshairStyle.CROSS_DOT -> {
                val gap = (sizePx * 0.22f).coerceAtLeast(strokePx * 1.6f)
                drawCrossLines(canvas, centerX, centerY, gap, halfSize, outlineStrokePaint)
                drawCrossLines(canvas, centerX, centerY, gap, halfSize, strokePaint)
                val dotRadius = (strokePx * 0.85f).coerceAtLeast(2f * density)
                canvas.drawCircle(centerX, centerY, dotRadius + (0.8f * density), Paint(outlineStrokePaint).apply {
                    style = Paint.Style.FILL
                })
                canvas.drawCircle(centerX, centerY, dotRadius, fillPaint)
            }

            CrosshairStyle.TACTICAL -> {
                val outerRadius = halfSize * 0.82f
                val innerGap = outerRadius * 0.35f
                val armOuter = halfSize

                // Broken outer ring arcs (4 quadrants)
                val ovalLeft = centerX - outerRadius
                val ovalTop = centerY - outerRadius
                val ovalRight = centerX + outerRadius
                val ovalBottom = centerY + outerRadius

                for (startAngle in listOf(20f, 110f, 200f, 290f)) {
                    canvas.drawArc(ovalLeft, ovalTop, ovalRight, ovalBottom, startAngle, 50f, false, outlineStrokePaint)
                    canvas.drawArc(ovalLeft, ovalTop, ovalRight, ovalBottom, startAngle, 50f, false, strokePaint)
                }

                // Precision crosshair arms
                drawCrossLines(canvas, centerX, centerY, innerGap, armOuter, outlineStrokePaint)
                drawCrossLines(canvas, centerX, centerY, innerGap, armOuter, strokePaint)

                // Center micro dot
                val dotRadius = (strokePx * 0.75f).coerceAtLeast(1.8f * density)
                canvas.drawCircle(centerX, centerY, dotRadius, fillPaint)
            }
        }
    }

    private fun drawCrossLines(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        gap: Float,
        extent: Float,
        paint: Paint
    ) {
        canvas.drawLine(cx - extent, cy, cx - gap, cy, paint)
        canvas.drawLine(cx + gap, cy, cx + extent, cy, paint)
        canvas.drawLine(cx, cy - extent, cx, cy - gap, paint)
        canvas.drawLine(cx, cy + gap, cx, cy + extent, paint)
    }
}
