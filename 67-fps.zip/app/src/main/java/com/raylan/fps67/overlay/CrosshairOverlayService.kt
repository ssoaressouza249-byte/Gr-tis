package com.raylan.fps67.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.raylan.fps67.MainActivity
import com.raylan.fps67.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.ceil

class CrosshairOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var windowManager: WindowManager? = null
    private var overlayView: CrosshairOverlayView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CrosshairStateHolder.loadIfNeeded(this)

        runCatching {
            createNotificationChannel()
            val notification = buildNotification()
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, serviceType)
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        setupOverlayWindow()
        observeCrosshairUpdates()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        runCatching {
            overlayView?.let { view ->
                windowManager?.removeViewImmediate(view)
            }
        }
        overlayView = null
        CrosshairStateHolder.setOverlayActive(false)
    }

    private fun setupOverlayWindow() {
        runCatching {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            windowManager = wm

            val config = CrosshairStateHolder.config.value
            val density = resources.displayMetrics.density
            val boxPx = computeOverlayBoxPx(config.sizeDp, config.strokeDp, density)

            val params = WindowManager.LayoutParams(
                boxPx,
                boxPx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
                x = config.offsetXPx
                y = config.offsetYPx
            }

            val view = CrosshairOverlayView(this, config)
            layoutParams = params
            overlayView = view
            wm.addView(view, params)
            CrosshairStateHolder.setOverlayActive(true)
        }.onFailure {
            CrosshairStateHolder.setOverlayActive(false)
            stopSelf()
        }
    }

    private fun observeCrosshairUpdates() {
        serviceScope.launch {
            CrosshairStateHolder.config.collectLatest { config ->
                val view = overlayView ?: return@collectLatest
                val params = layoutParams ?: return@collectLatest
                val wm = windowManager ?: return@collectLatest

                runCatching {
                    val density = resources.displayMetrics.density
                    val boxPx = computeOverlayBoxPx(config.sizeDp, config.strokeDp, density)
                    params.width = boxPx
                    params.height = boxPx
                    params.x = config.offsetXPx
                    params.y = config.offsetYPx
                    view.updateConfig(config)
                    wm.updateViewLayout(view, params)
                }
            }
        }
    }

    private fun computeOverlayBoxPx(sizeDp: Float, strokeDp: Float, density: Float): Int {
        return ceil(((sizeDp + strokeDp * 4f + 16f) * density).toDouble()).toInt().coerceAtLeast(64)
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, CrosshairOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Desativar", stopIntent)
            .build()
    }

    private class CrosshairOverlayView(
        context: Context,
        private var config: CrosshairConfig
    ) : View(context) {

        fun updateConfig(newConfig: CrosshairConfig) {
            config = newConfig
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val density = resources.displayMetrics.density
            CrosshairRenderer.draw(
                canvas = canvas,
                centerX = width / 2f,
                centerY = height / 2f,
                density = density,
                config = config
            )
        }
    }

    companion object {
        private const val CHANNEL_ID = "fps67_crosshair_overlay"
        private const val NOTIFICATION_ID = 6701
        private const val ACTION_STOP = "com.raylan.fps67.action.STOP_OVERLAY"

        fun start(context: Context) {
            runCatching {
                val intent = Intent(context, CrosshairOverlayService::class.java)
                context.startForegroundService(intent)
            }
        }

        fun stop(context: Context) {
            runCatching {
                context.stopService(Intent(context, CrosshairOverlayService::class.java))
                CrosshairStateHolder.setOverlayActive(false)
            }
        }
    }
}
