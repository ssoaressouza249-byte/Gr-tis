package com.raylan.fps67.ui.screens

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.fps67.data.DeviceMonitor
import com.raylan.fps67.data.DeviceTelemetry
import com.raylan.fps67.data.OptimizationCatalog
import com.raylan.fps67.data.OptimizationCategory
import com.raylan.fps67.data.OptimizationTweak
import com.raylan.fps67.overlay.CrosshairColorPreset
import com.raylan.fps67.overlay.CrosshairConfig
import com.raylan.fps67.overlay.CrosshairOverlayService
import com.raylan.fps67.overlay.CrosshairStateHolder
import com.raylan.fps67.overlay.CrosshairStyle
import com.raylan.fps67.shizuku.ShellLogEntry
import com.raylan.fps67.shizuku.ShizukuManager
import com.raylan.fps67.shizuku.ShizukuStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    OPTIMIZE("Otimizar"),
    CROSSHAIR("Mira"),
    SYSTEM("Sistema")
}

data class OptimizeUiState(
    val searchQuery: String = "",
    val selectedCategory: OptimizationCategory = OptimizationCategory.ALL,
    val activeTweakIds: Set<Int> = emptySet(),
    val isBatchProcessing: Boolean = false,
    val batchProgressText: String? = null,
    val inspectedTweak: OptimizationTweak? = null,
    val telemetry: DeviceTelemetry = DeviceTelemetry()
) {
    val activeCount: Int get() = activeTweakIds.size
    val isMasterBoostActive: Boolean get() = activeTweakIds.size >= 20
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: Context = application.applicationContext

    private val _selectedTab = MutableStateFlow(MainTab.OPTIMIZE)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    private val _optimizeState = MutableStateFlow(
        OptimizeUiState(telemetry = DeviceMonitor.readTelemetry(appContext))
    )
    val optimizeState: StateFlow<OptimizeUiState> = _optimizeState.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val shizukuStatus: StateFlow<ShizukuStatus> = ShizukuManager.status
    val shellLogs: StateFlow<List<ShellLogEntry>> = ShizukuManager.logs
    val crosshairConfig: StateFlow<CrosshairConfig> = CrosshairStateHolder.config
    val isOverlayActive: StateFlow<Boolean> = CrosshairStateHolder.isOverlayActive

    val filteredTweaks: StateFlow<List<OptimizationTweak>> = _optimizeState
        .combine(MutableStateFlow(OptimizationCatalog.tweaks)) { state, allTweaks ->
            val query = state.searchQuery.trim()
            allTweaks.filter { tweak ->
                val matchesCategory = state.selectedCategory == OptimizationCategory.ALL ||
                    tweak.category == state.selectedCategory
                val matchesQuery = query.isEmpty() ||
                    tweak.title.contains(query, ignoreCase = true) ||
                    tweak.subtitle.contains(query, ignoreCase = true) ||
                    tweak.applyCommand.contains(query, ignoreCase = true)
                matchesCategory && matchesQuery
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OptimizationCatalog.tweaks
        )

    init {
        ShizukuManager.initialize()
        CrosshairStateHolder.loadIfNeeded(appContext)
        refreshDeviceTelemetry()
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
        if (tab == MainTab.OPTIMIZE) {
            refreshDeviceTelemetry()
        }
    }

    fun refreshDeviceTelemetry() {
        _optimizeState.update {
            it.copy(telemetry = DeviceMonitor.readTelemetry(appContext))
        }
        ShizukuManager.refreshState()
    }

    fun updateSearchQuery(query: String) {
        _optimizeState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(category: OptimizationCategory) {
        _optimizeState.update { it.copy(selectedCategory = category) }
    }

    fun showTweakInfo(tweak: OptimizationTweak?) {
        _optimizeState.update { it.copy(inspectedTweak = tweak) }
    }

    fun connectOrAuthorizeShizuku() {
        ShizukuManager.connectOrAuthorize()
        val status = ShizukuManager.status.value
        if (!status.isBinderAlive) {
            showMessage("Shizuku inativo. Abra o app Shizuku e inicie o serviço.")
        }
    }

    fun testShizukuIdentity() {
        if (!ShizukuManager.status.value.isReady) {
            connectOrAuthorizeShizuku()
            return
        }
        viewModelScope.launch {
            val (ok, out) = ShizukuManager.testIdentity()
            showMessage(if (ok) "Shell ativo: $out" else "Falha no teste: $out")
        }
    }

    fun toggleTweak(tweak: OptimizationTweak, enable: Boolean) {
        if (tweak.isRestoreFactory) {
            restoreAllDefaults()
            return
        }

        if (!ShizukuManager.status.value.isReady) {
            connectOrAuthorizeShizuku()
            showMessage("Conecte e autorize o Shizuku primeiro.")
            return
        }

        viewModelScope.launch {
            if (enable) {
                val (ok, out) = ShizukuManager.runCommand(tweak.applyCommand)
                if (ok) {
                    _optimizeState.update {
                        it.copy(activeTweakIds = it.activeTweakIds + tweak.id)
                    }
                    showMessage("${tweak.title} ativado.")
                } else {
                    showMessage("Erro ao aplicar: ${out.lineSequence().firstOrNull().orEmpty()}")
                }
            } else {
                val revertCmd = tweak.revertCommand
                if (revertCmd != null) {
                    val (ok, out) = ShizukuManager.runCommand(revertCmd)
                    if (ok) {
                        _optimizeState.update {
                            it.copy(activeTweakIds = it.activeTweakIds - tweak.id)
                        }
                        showMessage("${tweak.title} revertido.")
                    } else {
                        showMessage("Erro ao reverter: ${out.lineSequence().firstOrNull().orEmpty()}")
                    }
                } else {
                    _optimizeState.update {
                        it.copy(activeTweakIds = it.activeTweakIds - tweak.id)
                    }
                }
            }
            refreshDeviceTelemetry()
        }
    }

    fun toggleMasterBoost() {
        val currentlyActive = _optimizeState.value.isMasterBoostActive
        if (currentlyActive) {
            restoreAllDefaults()
            return
        }

        if (!ShizukuManager.status.value.isReady) {
            connectOrAuthorizeShizuku()
            showMessage("Conecte e autorize o Shizuku para ativar o 67 FPS Boost.")
            return
        }

        if (_optimizeState.value.isBatchProcessing) return

        viewModelScope.launch {
            val boostTweaks = OptimizationCatalog.tweaks.filter { !it.isRestoreFactory }
            val activated = _optimizeState.value.activeTweakIds.toMutableSet()
            var successCount = 0

            _optimizeState.update {
                it.copy(isBatchProcessing = true, batchProgressText = "0/${boostTweaks.size}")
            }

            boostTweaks.forEachIndexed { index, tweak ->
                _optimizeState.update {
                    it.copy(batchProgressText = "${index + 1}/${boostTweaks.size}")
                }
                val (ok, _) = ShizukuManager.runCommand(tweak.applyCommand)
                if (ok) {
                    activated.add(tweak.id)
                    successCount++
                }
            }

            _optimizeState.update {
                it.copy(
                    activeTweakIds = activated,
                    isBatchProcessing = false,
                    batchProgressText = null
                )
            }
            refreshDeviceTelemetry()
            showMessage("67 FPS Boost aplicado: $successCount/${boostTweaks.size} comandos concluídos.")
        }
    }

    fun restoreAllDefaults() {
        if (!ShizukuManager.status.value.isReady) {
            connectOrAuthorizeShizuku()
            showMessage("Conecte e autorize o Shizuku para restaurar.")
            return
        }

        if (_optimizeState.value.isBatchProcessing) return

        viewModelScope.launch {
            val commands = OptimizationCatalog.restoreCommands
            _optimizeState.update {
                it.copy(isBatchProcessing = true, batchProgressText = "Restaurando...")
            }

            var okCount = 0
            commands.forEach { cmd ->
                val (ok, _) = ShizukuManager.runCommand(cmd)
                if (ok) okCount++
            }

            _optimizeState.update {
                it.copy(
                    activeTweakIds = emptySet(),
                    isBatchProcessing = false,
                    batchProgressText = null
                )
            }
            refreshDeviceTelemetry()
            showMessage("Padrões de fábrica restaurados ($okCount/${commands.size}).")
        }
    }

    fun clearLogs() {
        ShizukuManager.clearLogs()
    }

    fun canDrawOverlay(): Boolean = runCatching {
        Settings.canDrawOverlays(appContext)
    }.getOrDefault(false)

    fun openOverlayPermissionSettings(activityContext: Context) {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${activityContext.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activityContext.startActivity(intent)
        }.onFailure {
            showMessage("Não foi possível abrir as configurações de sobreposição.")
        }
    }

    fun toggleCrosshairOverlay(activityContext: Context) {
        if (CrosshairStateHolder.isOverlayActive.value) {
            CrosshairOverlayService.stop(appContext)
            showMessage("Mira flutuante desativada.")
        } else {
            if (!canDrawOverlay()) {
                showMessage("Conceda permissão de sobreposição para exibir a mira nos jogos.")
                openOverlayPermissionSettings(activityContext)
                return
            }
            CrosshairOverlayService.start(appContext)
            showMessage("Mira flutuante ativada.")
        }
    }

    fun setCrosshairStyle(style: CrosshairStyle) {
        CrosshairStateHolder.updateConfig(appContext) { it.copy(style = style) }
    }

    fun setCrosshairColor(preset: CrosshairColorPreset) {
        CrosshairStateHolder.updateConfig(appContext) { it.copy(colorArgb = preset.argb) }
    }

    fun setCrosshairSize(sizeDp: Float) {
        CrosshairStateHolder.updateConfig(appContext) { it.copy(sizeDp = sizeDp) }
    }

    fun setCrosshairStroke(strokeDp: Float) {
        CrosshairStateHolder.updateConfig(appContext) { it.copy(strokeDp = strokeDp) }
    }

    fun setCrosshairOpacity(opacity: Float) {
        CrosshairStateHolder.updateConfig(appContext) { it.copy(opacity = opacity) }
    }

    fun nudgeCrosshairOffset(dx: Int, dy: Int) {
        CrosshairStateHolder.updateConfig(appContext) {
            it.copy(
                offsetXPx = it.offsetXPx + dx,
                offsetYPx = it.offsetYPx + dy
            )
        }
    }

    fun centerCrosshair() {
        CrosshairStateHolder.updateConfig(appContext) {
            it.copy(offsetXPx = 0, offsetYPx = 0)
        }
    }

    fun showMessage(message: String) {
        _snackbarMessage.value = message
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }
}
